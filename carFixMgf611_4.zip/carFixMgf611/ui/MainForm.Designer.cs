﻿
namespace carFixMgf611
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiSymbolButton1 = new Sunny.UI.UISymbolButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.custFixinfo = new CxFlatUI.CxFlatRoundButton();
            this.custFixRand = new CxFlatUI.CxFlatRoundButton();
            this.custFixAdmin = new CxFlatUI.CxFlatRoundButton();
            this.custFixaView = new CxFlatUI.CxFlatRoundButton();
            this.custFixAdd = new CxFlatUI.CxFlatRoundButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.uiSymbolLabel1 = new Sunny.UI.UISymbolLabel();
            this.uiSymbolButton2 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton3 = new Sunny.UI.UISymbolButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // uiSymbolButton1
            // 
            this.uiSymbolButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolButton1.Location = new System.Drawing.Point(674, 279);
            this.uiSymbolButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton1.Name = "uiSymbolButton1";
            this.uiSymbolButton1.Size = new System.Drawing.Size(204, 120);
            this.uiSymbolButton1.TabIndex = 0;
            this.uiSymbolButton1.Text = "uiSymbolButton1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.custFixinfo);
            this.panel1.Controls.Add(this.custFixRand);
            this.panel1.Controls.Add(this.custFixAdmin);
            this.panel1.Controls.Add(this.custFixaView);
            this.panel1.Controls.Add(this.custFixAdd);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(911, 576);
            this.panel1.TabIndex = 2;
            // 
            // custFixinfo
            // 
            this.custFixinfo.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixinfo.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixinfo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixinfo.Location = new System.Drawing.Point(449, 463);
            this.custFixinfo.Name = "custFixinfo";
            this.custFixinfo.Size = new System.Drawing.Size(210, 54);
            this.custFixinfo.TabIndex = 12;
            this.custFixinfo.Text = "앱정보";
            this.custFixinfo.TextColor = System.Drawing.Color.White;
            // 
            // custFixRand
            // 
            this.custFixRand.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixRand.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixRand.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixRand.Location = new System.Drawing.Point(539, 379);
            this.custFixRand.Name = "custFixRand";
            this.custFixRand.Size = new System.Drawing.Size(210, 54);
            this.custFixRand.TabIndex = 11;
            this.custFixRand.Text = "랜덤 데이터 추가";
            this.custFixRand.TextColor = System.Drawing.Color.White;
            // 
            // custFixAdmin
            // 
            this.custFixAdmin.BackColor = System.Drawing.Color.White;
            this.custFixAdmin.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixAdmin.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixAdmin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixAdmin.Location = new System.Drawing.Point(607, 260);
            this.custFixAdmin.Name = "custFixAdmin";
            this.custFixAdmin.Size = new System.Drawing.Size(210, 54);
            this.custFixAdmin.TabIndex = 10;
            this.custFixAdmin.Text = "관리자 모드";
            this.custFixAdmin.TextColor = System.Drawing.Color.White;
            // 
            // custFixaView
            // 
            this.custFixaView.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixaView.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixaView.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixaView.Location = new System.Drawing.Point(539, 148);
            this.custFixaView.Name = "custFixaView";
            this.custFixaView.Size = new System.Drawing.Size(210, 54);
            this.custFixaView.TabIndex = 9;
            this.custFixaView.Text = "수리내역";
            this.custFixaView.TextColor = System.Drawing.Color.White;
            // 
            // custFixAdd
            // 
            this.custFixAdd.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixAdd.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixAdd.Location = new System.Drawing.Point(449, 40);
            this.custFixAdd.Name = "custFixAdd";
            this.custFixAdd.Size = new System.Drawing.Size(210, 54);
            this.custFixAdd.TabIndex = 8;
            this.custFixAdd.Text = "고객정보 접수";
            this.custFixAdd.TextColor = System.Drawing.Color.White;
            this.custFixAdd.Click += new System.EventHandler(this.custFixAdd_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::carFixMgf611.Properties.Resources._0004807457_002_20210610232001695;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 576);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // uiSymbolLabel1
            // 
            this.uiSymbolLabel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiSymbolLabel1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolLabel1.ForeColor = System.Drawing.Color.White;
            this.uiSymbolLabel1.Location = new System.Drawing.Point(113, 12);
            this.uiSymbolLabel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolLabel1.Name = "uiSymbolLabel1";
            this.uiSymbolLabel1.Padding = new System.Windows.Forms.Padding(28, 0, 0, 0);
            this.uiSymbolLabel1.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.uiSymbolLabel1.Size = new System.Drawing.Size(170, 35);
            this.uiSymbolLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolLabel1.Symbol = 61881;
            this.uiSymbolLabel1.SymbolColor = System.Drawing.Color.Yellow;
            this.uiSymbolLabel1.TabIndex = 2;
            this.uiSymbolLabel1.Text = "카센터 관리 앱 v1.0";
            // 
            // uiSymbolButton2
            // 
            this.uiSymbolButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton2.FillColor = System.Drawing.Color.Transparent;
            this.uiSymbolButton2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolButton2.Location = new System.Drawing.Point(852, 3);
            this.uiSymbolButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton2.Name = "uiSymbolButton2";
            this.uiSymbolButton2.RectColor = System.Drawing.Color.Red;
            this.uiSymbolButton2.Size = new System.Drawing.Size(47, 35);
            this.uiSymbolButton2.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton2.Symbol = 62164;
            this.uiSymbolButton2.TabIndex = 8;
            this.uiSymbolButton2.Click += new System.EventHandler(this.uiSymbolButton2_Click);
            // 
            // uiSymbolButton3
            // 
            this.uiSymbolButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton3.FillColor = System.Drawing.Color.Transparent;
            this.uiSymbolButton3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolButton3.Location = new System.Drawing.Point(797, 3);
            this.uiSymbolButton3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton3.Name = "uiSymbolButton3";
            this.uiSymbolButton3.RectColor = System.Drawing.Color.Red;
            this.uiSymbolButton3.Size = new System.Drawing.Size(49, 35);
            this.uiSymbolButton3.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton3.Symbol = 61767;
            this.uiSymbolButton3.TabIndex = 9;
            this.uiSymbolButton3.Click += new System.EventHandler(this.uiSymbolButton3_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 633);
            this.Controls.Add(this.uiSymbolButton3);
            this.Controls.Add(this.uiSymbolButton2);
            this.Controls.Add(this.uiSymbolLabel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.uiSymbolButton1);
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton uiSymbolButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolLabel uiSymbolLabel1;
        private Sunny.UI.UISymbolButton uiSymbolButton2;
        private CxFlatUI.CxFlatRoundButton custFixAdd;
        private CxFlatUI.CxFlatRoundButton custFixaView;
        private CxFlatUI.CxFlatRoundButton custFixinfo;
        private CxFlatUI.CxFlatRoundButton custFixRand;
        private CxFlatUI.CxFlatRoundButton custFixAdmin;
        private Sunny.UI.UISymbolButton uiSymbolButton3;
    }
}

