﻿
namespace carFixMgf611
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiSymbolButton1 = new Sunny.UI.UISymbolButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.custFixinfo = new System.Windows.Forms.Button();
            this.custFixRand = new System.Windows.Forms.Button();
            this.custFixAdmin = new System.Windows.Forms.Button();
            this.custFixaView = new System.Windows.Forms.Button();
            this.uiSymbolLabel1 = new Sunny.UI.UISymbolLabel();
            this.uiSymbolButton2 = new Sunny.UI.UISymbolButton();
            this.custFixAdd = new CxFlatUI.CxFlatRoundButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // uiSymbolButton1
            // 
            this.uiSymbolButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolButton1.Location = new System.Drawing.Point(674, 279);
            this.uiSymbolButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton1.Name = "uiSymbolButton1";
            this.uiSymbolButton1.Size = new System.Drawing.Size(204, 120);
            this.uiSymbolButton1.TabIndex = 0;
            this.uiSymbolButton1.Text = "uiSymbolButton1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.custFixAdd);
            this.panel1.Controls.Add(this.custFixinfo);
            this.panel1.Controls.Add(this.custFixRand);
            this.panel1.Controls.Add(this.custFixAdmin);
            this.panel1.Controls.Add(this.custFixaView);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(911, 576);
            this.panel1.TabIndex = 2;
            // 
            // custFixinfo
            // 
            this.custFixinfo.BackColor = System.Drawing.Color.Blue;
            this.custFixinfo.ForeColor = System.Drawing.Color.White;
            this.custFixinfo.Location = new System.Drawing.Point(585, 424);
            this.custFixinfo.Name = "custFixinfo";
            this.custFixinfo.Size = new System.Drawing.Size(204, 47);
            this.custFixinfo.TabIndex = 7;
            this.custFixinfo.Text = "앱 정보";
            this.custFixinfo.UseVisualStyleBackColor = false;
            this.custFixinfo.Click += new System.EventHandler(this.custFixinform_Click);
            // 
            // custFixRand
            // 
            this.custFixRand.BackColor = System.Drawing.Color.Blue;
            this.custFixRand.ForeColor = System.Drawing.Color.White;
            this.custFixRand.Location = new System.Drawing.Point(645, 325);
            this.custFixRand.Name = "custFixRand";
            this.custFixRand.Size = new System.Drawing.Size(204, 47);
            this.custFixRand.TabIndex = 6;
            this.custFixRand.Text = "랜덤 데이터 추가";
            this.custFixRand.UseVisualStyleBackColor = false;
            this.custFixRand.Click += new System.EventHandler(this.custFixRand_Click);
            // 
            // custFixAdmin
            // 
            this.custFixAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.custFixAdmin.ForeColor = System.Drawing.Color.White;
            this.custFixAdmin.Location = new System.Drawing.Point(674, 222);
            this.custFixAdmin.Name = "custFixAdmin";
            this.custFixAdmin.Size = new System.Drawing.Size(204, 47);
            this.custFixAdmin.TabIndex = 5;
            this.custFixAdmin.Text = "관리자 모드";
            this.custFixAdmin.UseVisualStyleBackColor = false;
            this.custFixAdmin.Click += new System.EventHandler(this.button4_Click);
            // 
            // custFixaView
            // 
            this.custFixaView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.custFixaView.ForeColor = System.Drawing.Color.White;
            this.custFixaView.Location = new System.Drawing.Point(645, 127);
            this.custFixaView.Name = "custFixaView";
            this.custFixaView.Size = new System.Drawing.Size(204, 41);
            this.custFixaView.TabIndex = 3;
            this.custFixaView.Text = "수리내역";
            this.custFixaView.UseVisualStyleBackColor = false;
            this.custFixaView.Click += new System.EventHandler(this.custFixaView_Click);
            // 
            // uiSymbolLabel1
            // 
            this.uiSymbolLabel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiSymbolLabel1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolLabel1.ForeColor = System.Drawing.Color.White;
            this.uiSymbolLabel1.Location = new System.Drawing.Point(113, 12);
            this.uiSymbolLabel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolLabel1.Name = "uiSymbolLabel1";
            this.uiSymbolLabel1.Padding = new System.Windows.Forms.Padding(28, 0, 0, 0);
            this.uiSymbolLabel1.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.uiSymbolLabel1.Size = new System.Drawing.Size(170, 35);
            this.uiSymbolLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolLabel1.TabIndex = 2;
            this.uiSymbolLabel1.Text = "카센터 관리 앱 v1.0";
            // 
            // uiSymbolButton2
            // 
            this.uiSymbolButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiSymbolButton2.Location = new System.Drawing.Point(799, 12);
            this.uiSymbolButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton2.Name = "uiSymbolButton2";
            this.uiSymbolButton2.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton2.TabIndex = 8;
            this.uiSymbolButton2.Text = "uiSymbolButton2";
            this.uiSymbolButton2.Click += new System.EventHandler(this.uiSymbolButton2_Click);
            // 
            // custFixAdd
            // 
            this.custFixAdd.ButtonType = CxFlatUI.ButtonType.Primary;
            this.custFixAdd.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.custFixAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.custFixAdd.Location = new System.Drawing.Point(585, 44);
            this.custFixAdd.Name = "custFixAdd";
            this.custFixAdd.Size = new System.Drawing.Size(210, 54);
            this.custFixAdd.TabIndex = 8;
            this.custFixAdd.Text = "고객정보 접수";
            this.custFixAdd.TextColor = System.Drawing.Color.White;
            this.custFixAdd.Click += new System.EventHandler(this.custFixAdd_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::carFixMgf611.Properties.Resources._0004807457_002_20210610232001695;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 576);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 633);
            this.Controls.Add(this.uiSymbolButton2);
            this.Controls.Add(this.uiSymbolLabel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.uiSymbolButton1);
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton uiSymbolButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button custFixinfo;
        private System.Windows.Forms.Button custFixRand;
        private System.Windows.Forms.Button custFixAdmin;
        private System.Windows.Forms.Button custFixaView;
        private Sunny.UI.UISymbolLabel uiSymbolLabel1;
        private Sunny.UI.UISymbolButton uiSymbolButton2;
        private CxFlatUI.CxFlatRoundButton custFixAdd;
    }
}

