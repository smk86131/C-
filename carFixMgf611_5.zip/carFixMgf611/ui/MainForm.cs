﻿using carFixMgf611.common;
using carFixMgf611.handler;
using carFixMgf611.ui;
using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace carFixMgf611
{
    public partial class MainForm : MaterialForm
    {
        OraHandler ora;
        ReceiptAdapter adapter;

        public MainForm()
        {
            InitializeComponent();
            CommUtil.initTheme(this);
            ora = new OraHandler();
            adapter = new ReceiptAdapter(ora);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void custFixAdd_Click(object sender, EventArgs e)
        {
            //new ReceiptForm(adapter).ShowDialog();
            //adapter.addReceiptDb();
            ora.insertDb();
        }

        private void custFixaView_Click(object sender, EventArgs e)
        {
            adapter.viewReceipt();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void custFixRand_Click(object sender, EventArgs e)
        {

        }

        private void custFixinform_Click(object sender, EventArgs e)
        {

        }

        private void uiSymbolButton2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void custFixAdd_Click_1(object sender, EventArgs e)
        {
            new ReceiptForm(adapter).ShowDialog();
            adapter.addReceiptDb();
        }

        private void uiSymbolButton3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
